const assert = require('assert');
test('hello world!', () => {
	assert.strictEqual('Hello, World!', 'Hello, World!');
});